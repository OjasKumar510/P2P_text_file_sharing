import socket
import struct

CHUNK_SIZE = 524288  # 512 KB standard chunk size

def send_file_data_as_chunk(chunk_id, data_bytes, sender_socket):
    """
    Builds an 8-byte header ([Chunk ID: 4B] + [Length: 4B]), attaches the 
    binary payload, and transmits everything continuously over TCP.
    """
    try:
        header = struct.pack('>II', chunk_id, len(data_bytes))
        sender_socket.sendall(header + data_bytes)
        return True
    except (TimeoutError, OSError):
        return False

def receive_exact_bytes(receiver_socket, max_size):
    """
    Guarantees collection of exactly max_size bytes from the continuous 
    TCP stream using a while-loop buffer.
    """
    buffer = bytearray()
    while len(buffer) < max_size:
        bytes_to_read = min(4096, max_size - len(buffer))
        packet = receiver_socket.recv(bytes_to_read)
        if not packet:
            raise ConnectionError("Peer disconnected mid-stream.")
        buffer.extend(packet)
    return bytes(buffer)

def receive_and_save_chunk(receiver_socket, destination_file_path, bitfield, bitfield_lock=None):
    """
    Parses incoming header, collects payload, writes data directly to file offset,
    and updates the local Bitfield state safely.
    """
    # 1. Parse 8-byte header
    header_bytes = receive_exact_bytes(receiver_socket, 8)
    chunk_id, payload_length = struct.unpack('>II', header_bytes)

    # 2. Receive exact payload size
    chunk_payload = receive_exact_bytes(receiver_socket, payload_length)

    # 3. Write directly to the target file offset
    with open(destination_file_path, "r+b") as f:
        f.seek(chunk_id * CHUNK_SIZE)
        f.write(chunk_payload)

    # 4. Thread-safe Bitfield state update
    if bitfield_lock:
        with bitfield_lock:
            bitfield[chunk_id] = 1
    else:
        bitfield[chunk_id] = 1

    return chunk_id