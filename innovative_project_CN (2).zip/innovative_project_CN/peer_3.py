import socket
import struct
import threading
import os
from p2p_engine import receive_and_save_chunk, CHUNK_SIZE

FILE_PATH = "peer3_file.bin"
TOTAL_CHUNKS = 4

bitfield = [0] * TOTAL_CHUNKS
bitfield_lock = threading.Lock()

def prepare_sparse_file():
    """Pre-allocates blank target file structure on disk."""
    if not os.path.exists(FILE_PATH):
        with open(FILE_PATH, "wb") as f:
            f.truncate(TOTAL_CHUNKS * CHUNK_SIZE)

def download_chunk(target_ip, target_port, chunk_id):
    """Connects to a peer socket, requests chunk, and saves to file offset."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((target_ip, target_port))

        # Request chunk ID
        sock.sendall(struct.pack('>I', chunk_id))

        # Process stream using p2p_engine
        received_id = receive_and_save_chunk(sock, FILE_PATH, bitfield, bitfield_lock)
        print(f"[Peer 3] Successfully fetched Chunk #{received_id} from Port {target_port}")
        sock.close()
    except Exception as e:
        print(f"[Peer 3] Failed to download Chunk #{chunk_id} from Port {target_port}: {e}")

if __name__ == "__main__":
    prepare_sparse_file()
    print("[Peer 3] Starting concurrent downloads...")

    # Spawn concurrent worker threads to download from different peers simultaneously
    t1 = threading.Thread(target=download_chunk, args=("127.0.0.1", 8002, 0)) # Chunk 0 from Peer 2
    t2 = threading.Thread(target=download_chunk, args=("127.0.0.1", 8001, 2)) # Chunk 2 from Peer 1

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    print(f"[Peer 3] Concurrent download complete. Final Bitfield: {bitfield}")