import socket
import struct
import threading
import os
from p2p_engine import receive_and_save_chunk, send_file_data_as_chunk, CHUNK_SIZE

FILE_PATH = "peer2_file.bin"
TOTAL_CHUNKS = 4
LISTEN_PORT = 8002

bitfield = [0] * TOTAL_CHUNKS
bitfield_lock = threading.Lock()

def prepare_sparse_file():
    """Pre-allocates blank target file structure on disk."""
    if not os.path.exists(FILE_PATH):
        with open(FILE_PATH, "wb") as f:
            f.truncate(TOTAL_CHUNKS * CHUNK_SIZE)

def download_chunk(target_ip, target_port, chunk_id):
    """Connects to a peer, requests a chunk, and processes the response stream."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((target_ip, target_port))

        # Send request for chunk_id
        sock.sendall(struct.pack('>I', chunk_id))

        # Receive framed stream and save to offset
        received_id = receive_and_save_chunk(sock, FILE_PATH, bitfield, bitfield_lock)
        print(f"[Peer 2] Successfully fetched Chunk #{received_id} from Port {target_port}")
        sock.close()
    except Exception as e:
        print(f"[Peer 2] Failed to download Chunk #{chunk_id}: {e}")

def handle_incoming_request(conn, addr):
    try:
        request_bytes = conn.recv(4)
        if request_bytes:
            chunk_id = struct.unpack('>I', request_bytes)[0]
            
            with bitfield_lock:
                has_chunk = bitfield[chunk_id] == 1

            if has_chunk:
                print(f"[Peer 2] Serving Chunk #{chunk_id} to {addr}")
                with open(FILE_PATH, "rb") as f:
                    f.seek(chunk_id * CHUNK_SIZE)
                    chunk_data = f.read(CHUNK_SIZE)
                send_file_data_as_chunk(chunk_id, chunk_data, conn)
            else:
                print(f"[Peer 2] Cannot serve Chunk #{chunk_id} (Not owned).")
    finally:
        conn.close()

def start_peer2_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", LISTEN_PORT))
    server.listen(5)
    print(f"[Peer 2] Server listening on port {LISTEN_PORT}...")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_incoming_request, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    prepare_sparse_file()

    # Start Peer 2 Server Thread to allow simultaneous upload capability
    threading.Thread(target=start_peer2_server, daemon=True).start()

    # Download Chunks 0 and 1 from Peer 1 (Port 8001)
    print("[Peer 2] Initiating downloads from Peer 1...")
    download_chunk("127.0.0.1", 8001, chunk_id=0)
    download_chunk("127.0.0.1", 8001, chunk_id=1)

    print(f"[Peer 2] Current Bitfield State: {bitfield}")
    
    # Keep server thread alive
    threading.Event().wait()