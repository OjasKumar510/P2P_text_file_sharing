chunk='a'*1024
lst=['a','b','c','d','e','f','g','h','i','j']
with open('parent_file.txt','w') as fl:
    count=0
    for i in range(5120):
        val=lst[int(i/512)]*1024
        fl.write(val)
        fl.write('\n')