from . import read_file
import random
import json
size=0
def main(id):
    chunk_peer={}
    chunk_list=read_file.read_store_chunk()
    #size+=len(chunk_list)
    #print("size: ",size)
    """
    visited=[]
    for i in range(size):
        visited.append(0)
    """
    count=0
    first=-1
    last=-1
    if id==1:
        first=0
        last=1
    if id==2:
        first=2
        last=3
    if id==3:
        first=4
        last=5
    if id==4:
        first=6
        last=7
    if id==5:
        first=8
        last=9
    for i in range(first,last+1):
        chunk_peer.update({i:chunk_list[i]})
    return chunk_peer
    """
    while count<size:
        val1=random.randint(1,3)
        val2=0
        while visited[val2]==1:
            val2=random.randint(0,size-1)
        #print("val2: ",val2)
        print('val1: ',val1)
        visited[val2]=1
        if val1==1:
            chunk_peer_1.update({val2:chunk_list[val2]})
        elif val1==2:
            chunk_peer_2.update({val2:chunk_list[val2]})
        else:
            chunk_peer_3.update({val2:chunk_list[val2]})
        count+=1
    """
    