def clear_string():
    return ""
def read_store_chunk():
    chunk_size=512*1024
    chunk_list=[]
    with open('parent_file.txt','r') as fl:
        data=fl.readline()
        strings=""
        count=0
        #print(data)
        while len(data)>0:
            if (count<chunk_size):
                left_data=""
                for i in range(len(data)):
                    if(count>=chunk_size):
                        left_data+=data[i:]
                        break
                    count+=1
                    strings+=data[i]
                data=clear_string()
                data+=left_data+fl.readline()
            else:
                count=0
                chunk_list.append(strings)
                strings=clear_string()
    return chunk_list