import socket
import struct
import threading
import os
from p2p_engine import send_file_data_as_chunk, CHUNK_SIZE

FILE_PATH = "peer1_file.bin"
TOTAL_CHUNKS = 4
LISTEN_PORT = 8001

# Peer 1 holds the full file
bitfield = [1] * TOTAL_CHUNKS

def initialize_dummy_file():
    """Generates a dummy binary file if one does not exist."""
    if not os.path.exists(FILE_PATH):
        with open(FILE_PATH, "wb") as f:
            for i in range(TOTAL_CHUNKS):
                f.write(bytes([i + 65]) * CHUNK_SIZE)  # Chunks of 'A', 'B', 'C', 'D'
        print(f"[Peer 1] Created seed file '{FILE_PATH}' ({TOTAL_CHUNKS * CHUNK_SIZE} bytes).")

def handle_incoming_request(conn, addr):
    try:
        # Read 4-byte chunk ID request
        request_bytes = conn.recv(4)
        if request_bytes:
            chunk_id = struct.unpack('>I', request_bytes)[0]
            print(f"[Peer 1] Serving request for Chunk #{chunk_id} to {addr}")

            # Read chunk from offset and send via engine
            with open(FILE_PATH, "rb") as f:
                f.seek(chunk_id * CHUNK_SIZE)
                chunk_data = f.read(CHUNK_SIZE)

            send_file_data_as_chunk(chunk_id, chunk_data, conn)
    except Exception as e:
        print(f"[Peer 1] Error serving {addr}: {e}")
    finally:
        conn.close()

def start_peer1_server():
    initialize_dummy_file()
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("127.0.0.1", LISTEN_PORT))
    server.listen(5)
    print(f"[Peer 1] Seeding active on port {LISTEN_PORT}. Bitfield: {bitfield}")

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_incoming_request, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_peer1_server()