import socket 
import threading
import json
import time
import random
from assign_read_file import distribute_chunk_to_peers,store_config_comm
chunk_list=distribute_chunk_to_peers.main(5)
size=512*10*1024
print(list(chunk_list.keys()))
#print(size)
HOST=store_config_comm.HOST
port_5_1=66
port_5_2=67
port_5_3=68
port_5_4=69
port_1_5=53
port_2_5=57
port_3_5=61
port_4_5=65
#stop_flag=threading.Event()
chunk_write_lock=threading.Lock()
set_flag=threading.Lock()
incomplete_flag={'val':0}
count_sent={'val':0}
count_dropped={'val':0}
count_flag=threading.Lock()
def generate_probablity():
    return random.random()
def receive_packet(HOSTS,PORT,sizes,chunk_write_lock,set_flag,incomplete_flag,chunk_list):
    receiver=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    receiver.bind((HOSTS,PORT))
    print("receiver listening at port : ", PORT)
    receiver.listen(1)
    conn,addr=receiver.accept()
    print("connection established with the sender for the receiver at port : ",PORT)
    stat=True
    size=10
    while stat:
        data=conn.recv(1024*1024)
        message="received successfully"
        conn.sendall(message.encode('utf-8'))
        if data.decode('utf-8')== "None":
            break
        dics=json.loads(data.decode('utf-8'))
        print("data received: ",dics['id'])
        with chunk_write_lock :
            if int(dics['id']) not in chunk_list.keys():
                chunk_list.update({int(dics['id']):dics['data']})
            print(list(chunk_list.keys()))
        if len(chunk_list)>=size:
            stat=False
            break
    message="about to close"
    conn.sendall(message.encode('utf-8'))
    data=conn.recv(1024)
    print("closing the connection at port : ",PORT)
    print(data.decode('utf-8'))
    conn.close()
    receiver.close()

def send_packet(HOSTS,PORT,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list,count_flag,count_sent,count_dropped):
    sender=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sender.connect((HOSTS,PORT))
    dics_sent={}
    stat=True
    #print(data.decode('utf-8'))
    print('initiating the transfer of data packets')
    while stat:
        data={}
        with chunk_write_lock:
            key_set=list(chunk_list.keys())
            if len(key_set)>0:
                for i in key_set:
                    if i not in dics_sent.keys():
                        #dics_sent.update({i:chunk_list[i]})
                        data.update({'id':i,'data':chunk_list[i]})
                        print('data sent: ',i)
                        break
        if len(data)>0 and generate_probablity()>=0.5:
            with count_flag:
                count_sent['val']+=1
            dics_sent.update({data['id']:data['data']})
            data_json_str=json.dumps(data).encode('utf-8')
            sender.sendall(data_json_str)
            datas=sender.recv(1024*1024)
            data_val=datas.decode('utf-8')
            if data_val =='about to close':
                #msg='closing'
                #sender.sendall(msg.encode('utf-8'))
                sender.close()
                print("closing the connection with port : ",PORT)
                stat=False
                break
            #print(data_val)
        elif len(data)>0:
            with count_flag:
                count_dropped['val']+=1
def store_to_file(set_flag,incomplete_flag,chunk_list,chunk_write_lock):
    stored_chunk={}
    size=10
    while len(stored_chunk)<size:
        current_time=time.time()
        val=time.time()
        while val-current_time<4.0:
            val=time.time()
        temp_buffer={}
        with chunk_write_lock:
            if len(chunk_list.keys())>0:
                print(list(chunk_list.keys()))
                for i in list(chunk_list.keys()):
                    if i not in stored_chunk.keys():
                        if i==0 or i-1 in stored_chunk.keys():
                            print("chunk id: ",i)
                            temp_buffer.update({i:chunk_list[i]})
                            stored_chunk.update({i:chunk_list[i]})
        for i in temp_buffer.keys():
            #if i not in stored_chunk.keys() and (i==0 or i-1 in stored_chunk.keys()):
            with open('peer_5_file.txt','a') as fl:
                fl.write(temp_buffer[i])
def main(HOST,port_5_1,port_5_2,port_5_3,port_5_4,port_1_5,port_2_5,port_3_5,port_4_5,size,chunk_list,chunk_write_lock,set_flag,incomplete_flag,count_flag,count_sent,count_dropped):
    #print(port_1,port_2,port_3,port_4)
    T1=threading.Thread(target=receive_packet,args=(HOST,port_5_1,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list))
    T2=threading.Thread(target=receive_packet,args=(HOST,port_5_2,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list))
    T3=threading.Thread(target=receive_packet,args=(HOST,port_5_3,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list))
    T4=threading.Thread(target=receive_packet,args=(HOST,port_5_4,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list))
    T5=threading.Thread(target=send_packet,args=(HOST,port_1_5,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list,count_flag,count_sent,count_dropped))
    T6=threading.Thread(target=send_packet,args=(HOST,port_2_5,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list,count_flag,count_sent,count_dropped))
    T7=threading.Thread(target=send_packet,args=(HOST,port_3_5,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list,count_flag,count_sent,count_dropped))
    T8=threading.Thread(target=send_packet,args=(HOST,port_4_5,size,chunk_write_lock,set_flag,incomplete_flag,chunk_list,count_flag,count_sent,count_dropped)) 
    T9=threading.Thread(target=store_to_file,args=(set_flag,incomplete_flag,chunk_list,chunk_write_lock))
    """
    while incomplete_flag>0:
        print(incomplete_flag)
        pass
    """
    T1.start()
    T2.start()
    T3.start()
    T4.start()
    T5.start()
    T6.start()
    T7.start()
    T8.start()
    T9.start()
    """
    receivers=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    receivers.bind((HOST,50001))
    receivers.listen(1)
    print("main receiver listening at address : ",HOST," : ",50001)
    #---to send that receiver is ready --------
    senders=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    data='receiver is ready'
    senders.sendto(data.encode('utf-8'),(HOST,50002))
    data,addr=senders.recvfrom(1024)
    print(data.decode("utf-8"))
    senders.sendto(data.encode('utf-8'),(HOST,50003))
    data,addr=senders.recvfrom(1024)
    print(data.decode('utf-8'))
    senders.close()
    #---to receive that receivers are configured-----
    count=0
    while count<2:
        data,addr=receivers.recvfrom(1024)
        print(data.decode('utf-8'))
        msg='ok initiating the packet transmission'
        receivers.sendto(msg.encode('utf-8'),addr)
        with set_flag:
            incomplete_flag-=1
        count+=1
    receivers.close()
    """
    #----initiating the packet transmission-----
    if T1.is_alive():
        T1.join()
    if T2.is_alive():
        T2.join()
    if T3.is_alive():
        T3.join()
    if T4.is_alive():
        T4.join()
    if T5.is_alive():
        T5.join()
    if T6.is_alive():
        T6.join()
    if T7.is_alive():
        T7.join()
    if T8.is_alive():
        T8.join()
    if T9.is_alive():
        T9.join()
    print("percentage dropped: ")
    total=count_sent['val']+count_dropped['val']
    drops=(float(count_dropped['val']))/(total)
    sent=(float(count_sent['val']))/(total)
    print(drops*100)
    print("percentage sent: ")
    print(sent*100)
if __name__=='__main__':
    main(HOST,port_5_1,port_5_2,port_5_3,port_5_4,port_1_5,port_2_5,port_3_5,port_4_5,size,chunk_list,chunk_write_lock,set_flag,incomplete_flag,count_flag,count_sent,count_dropped)